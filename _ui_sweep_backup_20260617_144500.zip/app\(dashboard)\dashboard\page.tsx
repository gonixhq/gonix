"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { useLanguage } from "@/lib/i18n";
import {
    ClipboardList,
    Clock,
    User,
    Stethoscope,
    Pill,
    CreditCard,
    CheckCircle,
    RefreshCw,
    Activity
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface QueueVisit {
    vn: string;
    visit_time: string;
    status: string;
    chief_complaint: string | null;
    created_at: string;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    patients: any;
}

function getWaitTime(createdAt: string, lang: string): string {
    const mins = Math.floor((Date.now() - new Date(createdAt).getTime()) / 60000);
    if (mins < 1) return lang === "en" ? "Just arrived" : "เพิ่งมา";
    if (mins < 60) return lang === "en" ? `${mins} m` : `${mins} นาที`;
    const hrs = Math.floor(mins / 60);
    const rem = mins % 60;
    return lang === "en" ? `${hrs}h ${rem}m` : `${hrs} ชม. ${rem} น.`;
}

export default function QueuePage() {
    const { t, language } = useLanguage();
    const [visits, setVisits] = useState<QueueVisit[]>([]);
    const [loading, setLoading] = useState(true);
    const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

    const fetchVisits = useCallback(async () => {
        const supabase = createClient();
        const today = new Date().toISOString().split("T")[0];

        const { data } = await supabase
            .from("visits")
            .select(`
                vn, visit_time, status, chief_complaint, created_at,
                patients!inner(hn, first_name, last_name, phone, gender)
            `)
            .eq("visit_date", today)
            .order("created_at", { ascending: true });

        setVisits((data as QueueVisit[]) || []);
        setLoading(false);
        setLastRefresh(new Date());
    }, []);

    useEffect(() => {
        fetchVisits();
        const interval = setInterval(fetchVisits, 30000); // 30s
        return () => clearInterval(interval);
    }, [fetchVisits]);

    const QUEUE_COLUMNS = [
        { key: "waiting", label: language === "en" ? "Waiting" : "รอซักประวัติ", icon: Clock, accent: "amber" },
        { key: "triaged", label: language === "en" ? "Triaged" : "คัดกรองแล้ว", icon: ClipboardList, accent: "sky" },
        { key: "with_doctor", label: language === "en" ? "Seeing Doctor" : "รอตรวจรักษา", icon: Stethoscope, accent: "teal" },
        { key: "waiting_medicine", label: language === "en" ? "Pharmacy" : "รอรับยา", icon: Pill, accent: "indigo" },
        { key: "waiting_payment", label: language === "en" ? "Cashier" : "รอชำระเงิน", icon: CreditCard, accent: "rose" },
        { key: "completed", label: language === "en" ? "Completed" : "เสร็จสิ้น", icon: CheckCircle, accent: "emerald" },
    ] as const;

    const tailwindColors: Record<string, { text: string, bg: string, border: string, ring: string, line: string }> = {
        amber: { text: "text-amber-600", bg: "bg-amber-50", border: "border-amber-200", ring: "ring-amber-500/20", line: "border-l-amber-400" },
        sky: { text: "text-sky-600", bg: "bg-sky-50", border: "border-sky-200", ring: "ring-sky-500/20", line: "border-l-sky-400" },
        teal: { text: "text-teal-600", bg: "bg-teal-50", border: "border-teal-200", ring: "ring-teal-500/20", line: "border-l-teal-400" },
        indigo: { text: "text-indigo-600", bg: "bg-indigo-50", border: "border-indigo-200", ring: "ring-indigo-500/20", line: "border-l-indigo-400" },
        rose: { text: "text-rose-600", bg: "bg-rose-50", border: "border-rose-200", ring: "ring-rose-500/20", line: "border-l-rose-400" },
        emerald: { text: "text-emerald-600", bg: "bg-emerald-50", border: "border-emerald-200", ring: "ring-emerald-500/20", line: "border-l-emerald-400" },
    };

    const grouped = QUEUE_COLUMNS.map((col) => ({
        ...col,
        visits: visits.filter((v) => v.status === col.key),
    }));

    const activeCount = visits.filter((v) => v.status !== "completed" && v.status !== "cancelled").length;

    return (
        <div className="space-y-8 animate-fade-in relative z-10 font-sans pb-10">
            {/* Sub-header — compact */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-1">
                <p className="text-sm font-medium text-slate-500" suppressHydrationWarning>
                    <span className="font-bold text-teal-700">
                        {new Date().toLocaleDateString(language === "en" ? "en-US" : "th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                    </span>
                    <span className="text-slate-300 mx-2">·</span>
                    <span><span className="font-bold text-slate-700 tabular-nums">{activeCount}</span> {language === "en" ? "Active Patients" : "คิวที่กำลังดำเนินการ"}</span>
                </p>
                <button
                    onClick={fetchVisits}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm bg-white/70 backdrop-blur-md border border-slate-200/60 shadow-sm text-slate-600 hover:text-teal-700 hover:bg-teal-50 hover:border-teal-200 transition-all"
                >
                    <RefreshCw className={cn("h-4 w-4", loading && "animate-spin text-teal-600")} />
                    <span className="hidden sm:inline">
                        {language === "en" ? "Last updated" : "อัพเดทล่าสุด"} {lastRefresh ? lastRefresh.toLocaleTimeString(language === "en" ? "en-US" : "th-TH", { hour: "2-digit", minute: "2-digit" }) : "—"}
                    </span>
                </button>
            </div>

            {/* Queue Board Canvas */}
            <div className="backdrop-blur-xl bg-gradient-to-br from-white/60 via-white/50 to-teal-50/30 border border-white/80 shadow-[0_8px_30px_rgb(0,0,0,0.04)] rounded-3xl p-6 overflow-x-auto">
                <div className="flex gap-4 min-w-max pb-4">
                    {grouped.map((col) => {
                        const Icon = col.icon;
                        const colors = tailwindColors[col.accent];

                        return (
                            <div key={col.key} className="w-[300px] flex-shrink-0 flex flex-col gap-4">
                                {/* Column Header */}
                                <div className={cn("rounded-2xl px-4 py-3 flex items-center gap-3 border shadow-sm backdrop-blur-md", colors.bg, colors.border)}>
                                    <div className={cn("h-8 w-8 rounded-full flex items-center justify-center bg-white shadow-sm", colors.text)}>
                                        <Icon className="h-4 w-4" />
                                    </div>
                                    <span className="text-sm font-bold text-slate-800 tracking-wide">{col.label}</span>
                                    <span className={cn(
                                        "ml-auto text-xs font-black rounded-full h-6 w-6 flex items-center justify-center shadow-inner",
                                        col.visits.length > 0 ? `bg-white ${colors.text}` : "bg-slate-100 text-slate-400"
                                    )}>
                                        {col.visits.length}
                                    </span>
                                </div>

                                {/* Visit Cards Container */}
                                <div className="flex flex-col gap-3 min-h-[500px] rounded-2xl bg-slate-100/50 p-2 border border-slate-200/50">
                                    {col.visits.length === 0 ? (
                                        <div className="flex-1 flex items-center justify-center text-center p-6">
                                            <p className="text-sm font-medium text-slate-400/80 border border-dashed border-slate-300 rounded-xl px-4 py-8 w-full">
                                                {language === "en" ? "Empty" : "ว่าง"}
                                            </p>
                                        </div>
                                    ) : (
                                        col.visits.map((visit) => {
                                            const pt = Array.isArray(visit.patients) ? visit.patients[0] : visit.patients;
                                            if (!pt) return null;

                                            // Make completed cards softer
                                            const isCompleted = col.key === "completed";

                                            // Smart Routing: "waiting" and "triaged" should route to screening.
                                            // Other statuses map directly to the active doctor/management visit console.
                                            const destinationUrl = ["waiting", "triaged"].includes(col.key)
                                                ? `/dashboard/screening/${visit.vn}`
                                                : `/dashboard/visits/${visit.vn}`;

                                            return (
                                                <Link
                                                    key={visit.vn}
                                                    href={destinationUrl}
                                                    className={cn(
                                                        "group block bg-white rounded-2xl p-4 shadow-sm border border-slate-200/60 hover:shadow-lg transition-all duration-300 relative overflow-hidden",
                                                        !isCompleted && "border-l-4",
                                                        !isCompleted && colors.line,
                                                        isCompleted ? "opacity-75 hover:opacity-100" : "hover:-translate-y-1"
                                                    )}
                                                >
                                                    {/* Background Accent Glow */}
                                                    <div className={cn("absolute -top-10 -right-10 w-24 h-24 rounded-full opacity-0 blur-2xl transition-opacity group-hover:opacity-20", colors.bg)} />

                                                    <div className="flex items-start justify-between mb-2">
                                                        <div className="flex items-center gap-2">
                                                            <div className="h-7 w-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500">
                                                                <User className="h-3.5 w-3.5" />
                                                            </div>
                                                            <span className="text-[15px] font-bold text-slate-800 truncate max-w-[140px]">
                                                                {pt.first_name} {pt.last_name?.charAt(0)}.
                                                            </span>
                                                        </div>
                                                    </div>

                                                    <div className="space-y-1.5 mb-3">
                                                        <p className="text-[11px] font-mono font-medium text-slate-500 bg-slate-50 inline-block px-2 py-0.5 rounded-md">
                                                            {visit.vn}
                                                        </p>
                                                        {visit.chief_complaint && (
                                                            <p className="text-xs font-medium text-slate-600 line-clamp-2 leading-relaxed">
                                                                {visit.chief_complaint}
                                                            </p>
                                                        )}
                                                    </div>

                                                    <div className="flex items-center justify-between mt-auto pt-3 border-t border-slate-100">
                                                        <span className="text-xs font-bold text-slate-400">
                                                            {visit.visit_time?.slice(0, 5)}
                                                        </span>
                                                        {!isCompleted && (
                                                            <Badge variant="outline" className={cn("text-[10px] px-2 py-0.5 border-transparent font-semibold", colors.bg, colors.text)}>
                                                                <Clock className="h-3 w-3 mr-1" />
                                                                {getWaitTime(visit.created_at, language)}
                                                            </Badge>
                                                        )}
                                                    </div>
                                                </Link>
                                            );
                                        })
                                    )}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
}
