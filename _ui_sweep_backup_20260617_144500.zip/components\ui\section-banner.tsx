import { type LucideIcon } from "lucide-react";

type BannerColor = "slate" | "teal" | "sky" | "amber" | "green" | "rose" | "indigo";

interface SectionBannerProps {
    icon: LucideIcon | React.ElementType;
    title: string;
    description?: string;
    color?: BannerColor;
}

const COLOR_STYLES: Record<BannerColor, {
    bg: string;
    accent: string;
    iconBg: string;
    iconText: string;
    titleText: string;
    descText: string;
}> = {
    slate:  { bg: "bg-slate-100",   accent: "bg-slate-500",   iconBg: "bg-white",       iconText: "text-slate-700",   titleText: "text-slate-900",   descText: "text-slate-600" },
    teal:   { bg: "bg-teal-100",    accent: "bg-teal-500",    iconBg: "bg-white",       iconText: "text-teal-700",    titleText: "text-teal-900",    descText: "text-teal-700" },
    sky:    { bg: "bg-sky-100",     accent: "bg-sky-500",     iconBg: "bg-white",       iconText: "text-sky-700",     titleText: "text-sky-900",     descText: "text-sky-700" },
    amber:  { bg: "bg-amber-100",   accent: "bg-amber-500",   iconBg: "bg-white",       iconText: "text-amber-700",   titleText: "text-amber-900",   descText: "text-amber-700" },
    green:  { bg: "bg-emerald-100", accent: "bg-emerald-500", iconBg: "bg-white",       iconText: "text-emerald-700", titleText: "text-emerald-900", descText: "text-emerald-700" },
    rose:   { bg: "bg-rose-100",    accent: "bg-rose-500",    iconBg: "bg-white",       iconText: "text-rose-700",    titleText: "text-rose-900",    descText: "text-rose-700" },
    indigo: { bg: "bg-indigo-100",  accent: "bg-indigo-500",  iconBg: "bg-white",       iconText: "text-indigo-700",  titleText: "text-indigo-900",  descText: "text-indigo-700" },
};

/**
 * Section banner — solid pastel accent with left color bar.
 * Use inside Card sections to label form/data groups.
 */
export function SectionBanner({ icon: Icon, title, description, color = "sky" }: SectionBannerProps) {
    const styles = COLOR_STYLES[color] || COLOR_STYLES.sky;
    return (
        <div className={`flex items-center gap-3 ${styles.bg} rounded-t-2xl px-5 py-3`}>
            <div className={`h-9 w-9 rounded-xl ${styles.iconBg} flex items-center justify-center shrink-0 shadow-sm ring-1 ring-white/60`}>
                <Icon className={`h-4 w-4 ${styles.iconText}`} strokeWidth={2.5} />
            </div>
            <div className="min-w-0">
                <div className={`${styles.titleText} font-bold text-base tracking-tight leading-tight`}>{title}</div>
                {description && (
                    <div className={`${styles.descText} text-xs mt-0.5 font-medium opacity-80`}>{description}</div>
                )}
            </div>
        </div>
    );
}

export default SectionBanner;
