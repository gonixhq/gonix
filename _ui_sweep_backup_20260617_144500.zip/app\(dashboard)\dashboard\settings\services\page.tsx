import { gatePermission } from "@/lib/auth/guard";
import { listAllServices } from "@/lib/actions/services";
import ServicesClient from "./services-client";

export default async function ServicesPage() {
    await gatePermission("settings.edit");
    const services = await listAllServices();
    return <ServicesClient initialServices={services} />;
}
