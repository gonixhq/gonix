"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import {
    Banknote, Plus, TrendingUp, Clock, CheckCircle2, Receipt, CreditCard,
} from "lucide-react";
import { useLanguage } from "@/lib/i18n";
import { cn } from "@/lib/utils";

interface Patient {
    prefix?: string | null;
    first_name?: string | null;
    last_name?: string | null;
}

interface Invoice {
    id: string;
    vn: string;
    hn: string;
    invoice_date: string;
    subtotal?: number | null;
    discount_amount?: number | null;
    total_amount: number;
    paid_amount?: number | null;
    balance_due?: number | null;
    status: string;
    patients: Patient | Patient[];
}

export default function FinanceClient({
    invoices,
    todayRevenue,
    pendingAmount,
    todayInvoiceCount,
}: {
    invoices: Invoice[];
    todayRevenue: number;
    pendingAmount: number;
    todayInvoiceCount: number;
}) {
    const { language } = useLanguage();
    const [filter, setFilter] = useState<"all" | "outstanding" | "paid" | "voided">("all");

    const outstandingCount = useMemo(
        () => invoices.filter(i => i.status === "issued" || i.status === "partial").length,
        [invoices]
    );
    const filteredInvoices = useMemo(() => {
        if (filter === "all") return invoices;
        if (filter === "outstanding") return invoices.filter(i => i.status === "issued" || i.status === "partial");
        if (filter === "paid") return invoices.filter(i => i.status === "paid");
        if (filter === "voided") return invoices.filter(i => i.status === "voided" || i.status === "refunded");
        return invoices;
    }, [invoices, filter]);

    const statusLabel: Record<string, string> = {
        draft: language === "en" ? "Draft" : "ร่าง",
        issued: language === "en" ? "Issued" : "รอชำระ",
        partial: language === "en" ? "Partial" : "ชำระบางส่วน",
        paid: language === "en" ? "Paid" : "ชำระแล้ว",
        voided: language === "en" ? "Voided" : "ยกเลิก",
        refunded: language === "en" ? "Refunded" : "คืนเงิน",
    };

    const statusColor: Record<string, string> = {
        draft: "bg-slate-100 text-slate-600 border-slate-200",
        issued: "bg-amber-100 text-amber-700 border-amber-200",
        partial: "bg-sky-100 text-sky-700 border-sky-200",
        paid: "bg-emerald-100 text-emerald-700 border-emerald-200",
        voided: "bg-slate-100 text-slate-500 border-slate-200",
        refunded: "bg-rose-100 text-rose-700 border-rose-200",
    };

    return (
        <div className="space-y-4 max-w-6xl mx-auto animate-fade-in pb-10">
            {/* Sub-header */}
            <div className="flex items-center justify-between gap-3 flex-wrap pt-1">
                <p className="text-sm font-medium text-slate-500 flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 font-bold text-teal-700">
                        <Banknote className="h-4 w-4" />
                        {language === "en" ? "Receipts & Payments" : "ใบเสร็จรับเงิน & การชำระเงิน"}
                    </span>
                </p>
                <Link href="/dashboard/finance/new">
                    <Button className="rounded-xl gap-1.5 h-9 bg-sky-600 hover:bg-sky-700 text-white shadow-sm shadow-sky-500/20">
                        <Plus className="h-4 w-4" />
                        {language === "en" ? "Create Receipt" : "สร้างใบเสร็จ"}
                    </Button>
                </Link>
            </div>

            {/* Stats — 3 cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Today Revenue */}
                <div className="rounded-2xl border bg-gradient-to-br from-emerald-50 to-teal-50/60 border-emerald-200 backdrop-blur-md p-4 shadow-sm shadow-emerald-100">
                    <div className="flex items-start justify-between">
                        <div>
                            <p className="text-[11px] font-black uppercase tracking-wider text-emerald-700">
                                {language === "en" ? "Today's Revenue" : "รายรับวันนี้"}
                            </p>
                            <p className="text-2xl font-black text-emerald-700 mt-1 tabular-nums">
                                <span className="text-base mr-0.5 opacity-70">฿</span>
                                {todayRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </p>
                        </div>
                        <div className="h-9 w-9 rounded-lg bg-white flex items-center justify-center shadow-sm">
                            <TrendingUp className="h-4 w-4 text-emerald-600" strokeWidth={2.5} />
                        </div>
                    </div>
                </div>

                {/* Pending */}
                <div className={`rounded-2xl border backdrop-blur-md p-4 ${
                    pendingAmount > 0
                        ? "bg-gradient-to-br from-amber-50 to-orange-50/60 border-amber-200 shadow-sm shadow-amber-100"
                        : "bg-white/50 border-slate-200/60"
                }`}>
                    <div className="flex items-start justify-between">
                        <div>
                            <p className={`text-[11px] font-black uppercase tracking-wider ${pendingAmount > 0 ? "text-amber-700" : "text-slate-500"}`}>
                                {language === "en" ? "Pending" : "รอชำระ"}
                            </p>
                            <p className={`text-2xl font-black mt-1 tabular-nums ${pendingAmount > 0 ? "text-amber-700" : "text-slate-400"}`}>
                                <span className="text-base mr-0.5 opacity-70">฿</span>
                                {pendingAmount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </p>
                        </div>
                        <div className="h-9 w-9 rounded-lg bg-white flex items-center justify-center shadow-sm">
                            <Clock className={`h-4 w-4 ${pendingAmount > 0 ? "text-amber-600" : "text-slate-400"}`} strokeWidth={2.5} />
                        </div>
                    </div>
                </div>

                {/* Today's invoices count */}
                <div className="rounded-2xl border bg-gradient-to-br from-sky-50 to-blue-50/60 border-sky-200 backdrop-blur-md p-4 shadow-sm shadow-sky-100">
                    <div className="flex items-start justify-between">
                        <div>
                            <p className="text-[11px] font-black uppercase tracking-wider text-sky-700">
                                {language === "en" ? "Today's Invoices" : "ใบเสร็จวันนี้"}
                            </p>
                            <p className="text-2xl font-black text-sky-700 mt-1 tabular-nums">{todayInvoiceCount}</p>
                        </div>
                        <div className="h-9 w-9 rounded-lg bg-white flex items-center justify-center shadow-sm">
                            <Receipt className="h-4 w-4 text-sky-600" strokeWidth={2.5} />
                        </div>
                    </div>
                </div>
            </div>

            {/* Invoice list */}
            <div className="gonix-card-premium overflow-hidden">
                <div className="px-5 py-3 border-b border-slate-200/60 flex items-center gap-2 flex-wrap">
                    <Banknote className="h-4 w-4 text-teal-700" />
                    <h2 className="text-sm font-bold text-slate-800">
                        {language === "en" ? "Recent Receipts" : "ใบเสร็จล่าสุด"}
                    </h2>
                    <span className="text-xs text-slate-400">({filteredInvoices.length}{filter !== "all" ? ` / ${invoices.length}` : ""})</span>
                    <div className="ml-auto flex items-center gap-1.5">
                        <FilterChip active={filter === "all"} onClick={() => setFilter("all")}>ทั้งหมด</FilterChip>
                        <FilterChip active={filter === "outstanding"} onClick={() => setFilter("outstanding")} color="amber">
                            ค้างชำระ ({outstandingCount})
                        </FilterChip>
                        <FilterChip active={filter === "paid"} onClick={() => setFilter("paid")} color="emerald">ชำระแล้ว</FilterChip>
                        <FilterChip active={filter === "voided"} onClick={() => setFilter("voided")}>ยกเลิก/คืน</FilterChip>
                    </div>
                </div>

                {filteredInvoices.length === 0 ? (
                    <div className="py-16 flex flex-col items-center justify-center">
                        <div className="h-14 w-14 rounded-2xl bg-slate-100 flex items-center justify-center mb-3">
                            <CreditCard className="h-7 w-7 text-slate-300" />
                        </div>
                        <p className="text-base font-bold text-slate-700">
                            {language === "en" ? "No Receipts Yet" : "ยังไม่มีใบเสร็จรับเงิน"}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                            {language === "en" ? "Receipts are created automatically when payment is collected." : "ใบเสร็จจะสร้างอัตโนมัติเมื่อเคาท์เตอร์รับเงิน"}
                        </p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-slate-50/60">
                                <tr className="text-[10px] font-black uppercase tracking-wider text-slate-500">
                                    <th className="text-left px-4 py-2.5">เลขที่</th>
                                    <th className="text-left px-4 py-2.5">ผู้ป่วย</th>
                                    <th className="text-left px-4 py-2.5 hidden md:table-cell">VN</th>
                                    <th className="text-left px-4 py-2.5 hidden sm:table-cell">วันที่</th>
                                    <th className="text-right px-4 py-2.5">ยอดรวม</th>
                                    <th className="text-right px-4 py-2.5 hidden lg:table-cell">คงเหลือ</th>
                                    <th className="text-center px-4 py-2.5">สถานะ</th>
                                    <th className="px-2"></th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredInvoices.map((inv) => {
                                    const pt = Array.isArray(inv.patients) ? inv.patients[0] : inv.patients;
                                    const balance = Number(inv.balance_due || 0);
                                    return (
                                        <tr
                                            key={inv.id}
                                            className="border-t border-slate-100 hover:bg-teal-50/40 transition-colors group cursor-pointer"
                                            onClick={() => window.location.href = `/dashboard/finance/${inv.id}`}
                                        >
                                            <td className="px-4 py-3">
                                                <span className="font-mono text-[11px] font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded">
                                                    {inv.id}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3">
                                                <div className="font-bold text-slate-800 truncate">
                                                    {pt?.prefix}{pt?.first_name} {pt?.last_name}
                                                </div>
                                                <div className="text-[11px] font-mono text-slate-500">HN: {inv.hn}</div>
                                            </td>
                                            <td className="px-4 py-3 hidden md:table-cell">
                                                <span className="font-mono text-xs text-slate-600">{inv.vn}</span>
                                            </td>
                                            <td className="px-4 py-3 hidden sm:table-cell text-xs text-slate-600 tabular-nums">
                                                {new Date(inv.invoice_date).toLocaleDateString(language === "en" ? "en-US" : "th-TH", { day: "numeric", month: "short", year: "2-digit" })}
                                            </td>
                                            <td className="px-4 py-3 text-right">
                                                <span className="font-bold text-slate-800 tabular-nums">
                                                    ฿{Number(inv.total_amount || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-right hidden lg:table-cell">
                                                <span className={`font-bold tabular-nums ${balance > 0 ? "text-amber-700" : "text-slate-400"}`}>
                                                    {balance > 0 ? `฿${balance.toLocaleString(undefined, { minimumFractionDigits: 2 })}` : "—"}
                                                </span>
                                            </td>
                                            <td className="px-4 py-3 text-center">
                                                <div className={cn(
                                                    "inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-bold border",
                                                    statusColor[inv.status] || statusColor.draft
                                                )}>
                                                    {inv.status === "paid" && <CheckCircle2 className="h-3 w-3" />}
                                                    {statusLabel[inv.status] || inv.status}
                                                </div>
                                            </td>
                                            <td className="px-2 py-3">
                                                <Link href={`/dashboard/finance/${inv.id}`} onClick={(e) => e.stopPropagation()}>
                                                    <Button variant="outline" size="sm" className="rounded-lg text-xs h-7 hover:border-teal-300 hover:text-teal-700">
                                                        {language === "en" ? "View" : "ดู"}
                                                    </Button>
                                                </Link>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}

function FilterChip({
    active, onClick, children, color = "slate",
}: {
    active: boolean;
    onClick: () => void;
    children: React.ReactNode;
    color?: "slate" | "amber" | "emerald";
}) {
    const activeStyles = {
        slate: "bg-slate-700 text-white",
        amber: "bg-amber-600 text-white shadow-sm shadow-amber-500/30",
        emerald: "bg-emerald-600 text-white shadow-sm shadow-emerald-500/30",
    }[color];
    return (
        <button
            type="button"
            onClick={onClick}
            className={`px-2.5 h-7 rounded-md text-[11px] font-bold uppercase tracking-wider transition-all ${
                active ? activeStyles : "bg-slate-100 text-slate-600 hover:bg-slate-200"
            }`}
        >
            {children}
        </button>
    );
}
