import { createClient } from "@/lib/supabase/server";
import { gatePermission } from "@/lib/auth/guard";
import { bangkokDate } from "@/lib/utils/date";
import FinanceClient from "./finance-client";

export const dynamic = "force-dynamic";

export default async function FinancePage() {
    await gatePermission("finance.view");
    const supabase = await createClient();
    const today = bangkokDate();

    // Calculate Asia/Bangkok day window — start..end ของวันนี้
    const dayStartISO = new Date(`${today}T00:00:00+07:00`).toISOString();
    const nextDate = new Date(`${today}T00:00:00+07:00`);
    nextDate.setDate(nextDate.getDate() + 1);
    const dayEndISO = nextDate.toISOString();

    // Fetch recent invoice headers
    const { data: invoices } = await supabase
        .from("invoice_headers")
        .select(`
            id, vn, hn, invoice_date, subtotal, discount_amount, total_amount, paid_amount, balance_due, status,
            patients!inner(prefix, first_name, last_name)
        `)
        .order("created_at", { ascending: false })
        .limit(50);

    // Today's paid revenue (filter ตาม created_at — Asia/Bangkok window)
    const { data: todayPaid } = await supabase
        .from("invoice_headers")
        .select("total_amount, paid_amount")
        .eq("status", "paid")
        .gte("created_at", dayStartISO)
        .lt("created_at", dayEndISO);

    // Pending (issued or partial) — ทั้งระบบ ไม่ใช่แค่วันนี้
    const { data: pending } = await supabase
        .from("invoice_headers")
        .select("balance_due")
        .in("status", ["issued", "partial"]);

    // Today's invoice count (Asia/Bangkok window)
    const { count: todayInvoiceCount } = await supabase
        .from("invoice_headers")
        .select("id", { count: "exact", head: true })
        .gte("created_at", dayStartISO)
        .lt("created_at", dayEndISO);

    const todayRevenue = (todayPaid || []).reduce((s, r) => s + Number(r.paid_amount || r.total_amount || 0), 0);
    const pendingAmount = (pending || []).reduce((s, r) => s + Number(r.balance_due || 0), 0);

    return (
        <FinanceClient
            invoices={invoices || []}
            todayRevenue={todayRevenue}
            pendingAmount={pendingAmount}
            todayInvoiceCount={todayInvoiceCount || 0}
        />
    );
}
