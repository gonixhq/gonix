/**
 * Horizontal Form Layout — shared compact form pattern.
 *
 * Usage:
 *   <HorizontalForm>
 *     <Section title="ข้อมูลพื้นฐาน" icon={FileText} color="slate">
 *       <FieldRow label="ชื่อ" required>
 *         <Input ... />
 *       </FieldRow>
 *       <SubHeader>กลุ่มย่อย</SubHeader>
 *       <FieldRow label="HN" colSpan={2}>...</FieldRow>
 *     </Section>
 *   </HorizontalForm>
 */

import * as React from "react";

type SectionColor = "slate" | "amber" | "emerald" | "sky" | "rose" | "teal" | "purple" | "indigo";

const SECTION_STYLES: Record<SectionColor, { header: string; iconBg: string; border: string }> = {
    slate: {
        header: "from-slate-100 to-slate-50 text-slate-800 border-slate-300",
        iconBg: "bg-slate-200 text-slate-700",
        border: "border-slate-200",
    },
    amber: {
        header: "from-amber-100 to-amber-50 text-amber-900 border-amber-300",
        iconBg: "bg-amber-200 text-amber-800",
        border: "border-amber-200",
    },
    emerald: {
        header: "from-emerald-100 to-emerald-50 text-emerald-900 border-emerald-300",
        iconBg: "bg-emerald-200 text-emerald-800",
        border: "border-emerald-200",
    },
    sky: {
        header: "from-sky-100 to-sky-50 text-sky-900 border-sky-300",
        iconBg: "bg-sky-200 text-sky-800",
        border: "border-sky-200",
    },
    rose: {
        header: "from-rose-100 to-rose-50 text-rose-900 border-rose-300",
        iconBg: "bg-rose-200 text-rose-800",
        border: "border-rose-200",
    },
    teal: {
        header: "from-teal-100 to-teal-50 text-teal-900 border-teal-300",
        iconBg: "bg-teal-200 text-teal-800",
        border: "border-teal-200",
    },
    purple: {
        header: "from-purple-100 to-purple-50 text-purple-900 border-purple-300",
        iconBg: "bg-purple-200 text-purple-800",
        border: "border-purple-200",
    },
    indigo: {
        header: "from-indigo-100 to-indigo-50 text-indigo-900 border-indigo-300",
        iconBg: "bg-indigo-200 text-indigo-800",
        border: "border-indigo-200",
    },
};

/** Container that wraps multiple sections — provides consistent spacing */
export function HorizontalForm({ children, className }: { children: React.ReactNode; className?: string }) {
    return <div className={`space-y-4 ${className || ""}`}>{children}</div>;
}

/** Section box with colored header + 2-column grid content */
export function Section({
    title,
    icon: Icon,
    color = "slate",
    children,
    description,
    actions,
}: {
    title: string;
    icon?: React.ElementType;
    color?: SectionColor;
    children: React.ReactNode;
    description?: string;
    actions?: React.ReactNode;
}) {
    const styles = SECTION_STYLES[color];
    return (
        <div className={`rounded-2xl border-2 ${styles.border} shadow-sm bg-white overflow-hidden`}>
            <div className={`flex items-center justify-between gap-3 px-4 py-3 bg-gradient-to-r ${styles.header} border-b-2`}>
                <div className="flex items-center gap-2.5 min-w-0">
                    {Icon && (
                        <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${styles.iconBg}`}>
                            <Icon className="h-5 w-5" />
                        </div>
                    )}
                    <div className="min-w-0">
                        <h2 className="text-lg font-bold truncate">{title}</h2>
                        {description && <p className="text-[12px] opacity-70 truncate">{description}</p>}
                    </div>
                </div>
                {actions && <div className="shrink-0">{actions}</div>}
            </div>
            <div className="p-4 grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
                {children}
            </div>
        </div>
    );
}

/** Field row: label LEFT (fixed width), input RIGHT */
export function FieldRow({
    label,
    required,
    children,
    colSpan = 1,
    labelWidth = 150,
    align = "center",
    hint,
}: {
    label: React.ReactNode;
    required?: boolean;
    children: React.ReactNode;
    /** 1 = half (default), 2 = full row */
    colSpan?: 1 | 2;
    /** Label column width in px (default 150) */
    labelWidth?: number;
    /** Vertical alignment of label */
    align?: "center" | "start";
    /** Helper text below input */
    hint?: React.ReactNode;
}) {
    return (
        <div
            className={`grid items-${align} gap-3 ${colSpan === 2 ? "md:col-span-2" : ""}`}
            style={{ gridTemplateColumns: `${labelWidth}px 1fr` }}
        >
            <label
                className={`text-[16px] font-semibold text-right ${required ? "text-red-600" : "text-slate-700"} truncate ${align === "start" ? "pt-2.5" : ""}`}
            >
                {required && <span className="mr-0.5">*</span>}{label}
            </label>
            <div className="min-w-0">
                {children}
                {hint && <p className="text-[12px] text-slate-500 mt-1">{hint}</p>}
            </div>
        </div>
    );
}

/** Sub-header inside a section (divider with label) */
export function SubHeader({ children, className }: { children: React.ReactNode; className?: string }) {
    return (
        <div
            className={`col-span-full text-[13px] font-bold uppercase tracking-wider text-slate-500 pb-2 mb-1 border-b border-slate-200 flex items-center gap-1.5 ${className || ""}`}
        >
            <span className="h-1 w-5 bg-slate-300 rounded-full" />
            {children}
        </div>
    );
}

/** Standardized input/select class strings — use to keep visual consistency */
export const FORM_INPUT_CLS = "h-11 text-[16px] rounded-lg border-slate-300 focus-visible:ring-teal-500/20 focus-visible:border-teal-500";
export const FORM_SELECT_CLS = "w-full h-11 px-3 text-[16px] rounded-lg border border-slate-300 bg-white focus:outline-none focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500";
