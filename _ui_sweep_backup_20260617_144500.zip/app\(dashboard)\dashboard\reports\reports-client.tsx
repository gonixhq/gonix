"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
    BarChart3, Users, Activity, TrendingUp, Calendar, Wallet,
    Download, AlertTriangle, Pill, Sparkles, FileText, ChevronRight,
    Banknote, CreditCard, QrCode, ArrowLeftRight, X,
} from "lucide-react";
import type { ReportSummary, OutstandingInvoice } from "@/lib/actions/reports";

const PAYMENT_METHOD_LABEL: Record<string, string> = {
    cash: "เงินสด",
    transfer: "โอน",
    credit_card: "บัตรเครดิต",
    qr_promptpay: "QR / พร้อมเพย์",
    insurance: "ประกัน",
    nhso: "สปสช.",
    package: "หักจากคอส",
    points: "แต้มสะสม",
    mixed: "ผสม",
};

const PAYMENT_METHOD_ICON: Record<string, React.ElementType> = {
    cash: Banknote,
    transfer: ArrowLeftRight,
    credit_card: CreditCard,
    qr_promptpay: QrCode,
};

const ITEM_TYPE_LABEL: Record<string, string> = {
    drug: "ยา",
    supply: "เวชภัณฑ์",
    doctor_fee: "ค่าตรวจ",
    procedure: "หัตถการ",
    service: "บริการ",
    package: "คอสบริการ",
    lab: "แล็บ",
    lab_external: "แล็บภายนอก",
    other: "อื่นๆ",
};

const ITEM_TYPE_COLOR: Record<string, string> = {
    drug: "bg-amber-100 text-amber-700",
    supply: "bg-indigo-100 text-indigo-700",
    doctor_fee: "bg-sky-100 text-sky-700",
    procedure: "bg-rose-100 text-rose-700",
    service: "bg-teal-100 text-teal-700",
    package: "bg-pink-100 text-pink-700",
    lab: "bg-purple-100 text-purple-700",
    other: "bg-slate-100 text-slate-700",
};

const CATEGORY_LABEL: Record<string, string> = {
    general_med: "เวชกรรมทั่วไป",
    aesthetic: "ความงาม",
    wound_care: "ทำแผล",
    med_cert: "ใบรับรอง",
    checkup: "ตรวจสุขภาพ",
    std_test: "ตรวจ STD",
};

const STATUS_LABEL: Record<string, string> = {
    partial: "ชำระบางส่วน",
    issued: "ค้างชำระ",
};

function fmt(n: number): string {
    return n.toLocaleString("th-TH", { minimumFractionDigits: 0 });
}
function fmt2(n: number): string {
    return n.toLocaleString("th-TH", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function formatDateThai(d: string): string {
    return new Date(d + "T00:00:00").toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
}

export default function ReportsClient({
    summary, outstanding, startDate, endDate, today,
}: {
    summary: ReportSummary;
    outstanding: OutstandingInvoice[];
    startDate: string;
    endDate: string;
    today: string;
}) {
    const router = useRouter();
    const [showOutstanding, setShowOutstanding] = useState(false);
    const [tab, setTab] = useState<"overview" | "sales" | "items">("overview");

    // Quick range presets
    function applyPreset(preset: "today" | "week" | "month" | "lastMonth") {
        const now = new Date(today + "T00:00:00");
        let start = today, end = today;
        if (preset === "today") {
            start = today; end = today;
        } else if (preset === "week") {
            const dow = now.getDay() === 0 ? 6 : now.getDay() - 1;
            const monday = new Date(now); monday.setDate(now.getDate() - dow);
            start = monday.toLocaleDateString("sv-SE"); end = today;
        } else if (preset === "month") {
            const [y, m] = today.split("-");
            start = `${y}-${m}-01`; end = today;
        } else if (preset === "lastMonth") {
            const lm = new Date(now.getFullYear(), now.getMonth() - 1, 1);
            const lmEnd = new Date(now.getFullYear(), now.getMonth(), 0);
            start = lm.toLocaleDateString("sv-SE"); end = lmEnd.toLocaleDateString("sv-SE");
        }
        router.push(`/dashboard/reports?start=${start}&end=${end}`);
    }

    function exportCSV() {
        const lines: string[] = [];
        lines.push(`รายงานสรุป,${formatDateThai(startDate)} ถึง ${formatDateThai(endDate)}`);
        lines.push("");
        lines.push("=== สรุปยอด ===");
        lines.push(`รายรับ (ชำระจริง),${summary.totalRevenue}`);
        lines.push(`ยอดออกบิล,${summary.totalBilled}`);
        lines.push(`ค้างชำระ,${summary.outstanding}`);
        lines.push(`จำนวนใบเสร็จ,${summary.invoiceCount}`);
        lines.push(`Visit ทั้งหมด,${summary.totalVisits}`);
        lines.push(`ผู้ป่วยใหม่,${summary.newPatients}`);
        lines.push("");
        lines.push("=== รายรับรายวัน ===");
        lines.push("วันที่,ยอดรับ");
        summary.revenueByDay.forEach(r => lines.push(`${r.date},${r.amount}`));
        lines.push("");
        lines.push("=== แยกตามวิธีชำระ ===");
        lines.push("วิธีชำระ,จำนวนครั้ง,ยอด");
        summary.revenueByMethod.forEach(r => lines.push(`${PAYMENT_METHOD_LABEL[r.method] || r.method},${r.count},${r.amount}`));
        lines.push("");
        lines.push("=== ยอดขายตามประเภท ===");
        lines.push("ประเภท,จำนวนรายการ,ยอด");
        summary.salesByType.forEach(r => lines.push(`${ITEM_TYPE_LABEL[r.type] || r.type},${r.count},${r.amount}`));
        lines.push("");
        lines.push("=== รายการขายดี ===");
        lines.push("ชื่อ,ประเภท,จำนวน,ยอด");
        summary.topItems.forEach(r => lines.push(`"${r.name}",${ITEM_TYPE_LABEL[r.type] || r.type},${r.qty},${r.amount}`));

        const csv = "﻿" + lines.join("\n");  // BOM for Excel Thai
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `report-${startDate}_${endDate}.csv`;
        a.click();
        URL.revokeObjectURL(url);
    }

    const maxDayRevenue = Math.max(...summary.revenueByDay.map(r => r.amount), 1);

    return (
        <div className="space-y-4 max-w-7xl mx-auto animate-fade-in pb-12">
            {/* Header + Date range */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-teal-700" />
                    <h1 className="text-lg font-bold text-slate-800">รายงาน & สถิติ</h1>
                    <span className="text-slate-300">·</span>
                    <span className="text-sm text-slate-500">{formatDateThai(startDate)} — {formatDateThai(endDate)}</span>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                    {/* Presets */}
                    <div className="inline-flex items-center bg-slate-100 rounded-xl p-1 gap-0.5">
                        <PresetBtn onClick={() => applyPreset("today")}>วันนี้</PresetBtn>
                        <PresetBtn onClick={() => applyPreset("week")}>สัปดาห์</PresetBtn>
                        <PresetBtn onClick={() => applyPreset("month")}>เดือนนี้</PresetBtn>
                        <PresetBtn onClick={() => applyPreset("lastMonth")}>เดือนก่อน</PresetBtn>
                    </div>

                    {/* Custom range */}
                    <form method="get" className="inline-flex items-center gap-1.5">
                        <input type="date" name="start" defaultValue={startDate} max={today}
                            className="h-9 px-2 rounded-lg border border-slate-300 text-sm font-mono" />
                        <span className="text-slate-400 text-xs">–</span>
                        <input type="date" name="end" defaultValue={endDate} max={today}
                            className="h-9 px-2 rounded-lg border border-slate-300 text-sm font-mono" />
                        <Button type="submit" size="sm" variant="outline" className="rounded-lg h-9 text-xs">ดู</Button>
                    </form>

                    <Button onClick={exportCSV} size="sm" className="rounded-lg h-9 gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white">
                        <Download className="h-4 w-4" /> Excel
                    </Button>
                </div>
            </div>

            {/* Outstanding alert */}
            {summary.outstanding > 0 && (
                <button
                    onClick={() => setShowOutstanding(true)}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-amber-50 border-2 border-amber-200 hover:bg-amber-100/60 transition-colors text-left"
                >
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                    <div className="flex-1">
                        <span className="font-bold text-amber-900">ค้างชำระทั้งหมด ฿{fmt2(outstanding.reduce((s, o) => s + o.balance, 0))}</span>
                        <span className="text-sm text-amber-700 ml-2">({outstanding.length} ใบเสร็จ)</span>
                    </div>
                    <ChevronRight className="h-4 w-4 text-amber-600" />
                </button>
            )}

            {/* Top stat cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                <StatCard icon={Wallet} label="รายรับ (ชำระจริง)" value={`฿${fmt(summary.totalRevenue)}`} color="emerald" sub={`ออกบิล ฿${fmt(summary.totalBilled)}`} />
                <StatCard icon={AlertTriangle} label="ค้างชำระ" value={`฿${fmt(summary.outstanding)}`} color="amber" sub={`${summary.partialCount} บางส่วน`} />
                <StatCard icon={Activity} label="Visit" value={fmt(summary.totalVisits)} color="sky" sub={`เสร็จ ${summary.completedVisits} · ยกเลิก ${summary.cancelledVisits}`} />
                <StatCard icon={Users} label="ผู้ป่วยใหม่" value={fmt(summary.newPatients)} color="violet" sub={`ใบเสร็จ ${summary.invoiceCount} ใบ`} />
            </div>

            {/* Tabs */}
            <div className="inline-flex items-center bg-slate-100 rounded-xl p-1 gap-0.5">
                <TabBtn active={tab === "overview"} onClick={() => setTab("overview")}>ภาพรวม</TabBtn>
                <TabBtn active={tab === "sales"} onClick={() => setTab("sales")}>ยอดขาย</TabBtn>
                <TabBtn active={tab === "items"} onClick={() => setTab("items")}>รายการขายดี</TabBtn>
            </div>

            {/* ── OVERVIEW ── */}
            {tab === "overview" && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Revenue by day */}
                    <div className="gonix-card-premium overflow-hidden">
                        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                            <TrendingUp className="h-4 w-4 text-emerald-600" />
                            <h2 className="text-sm font-bold text-slate-800">รายรับรายวัน</h2>
                        </div>
                        <div className="p-5">
                            {summary.revenueByDay.length === 0 ? (
                                <p className="text-center text-sm text-slate-400 py-8">ไม่มีรายรับในช่วงนี้</p>
                            ) : (
                                <div className="space-y-2">
                                    {summary.revenueByDay.slice(-14).map(r => {
                                        const pct = Math.round((r.amount / maxDayRevenue) * 100);
                                        return (
                                            <div key={r.date} className="flex items-center gap-3">
                                                <span className="text-xs text-slate-500 w-16 shrink-0 text-right">
                                                    {new Date(r.date + "T00:00:00").toLocaleDateString("th-TH", { day: "numeric", month: "short" })}
                                                </span>
                                                <div className="flex-1 h-5 bg-slate-100 rounded-full overflow-hidden">
                                                    <div className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 rounded-full transition-all" style={{ width: `${pct}%` }} />
                                                </div>
                                                <span className="text-xs font-bold text-emerald-700 w-20 text-right tabular-nums">฿{fmt(r.amount)}</span>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Payment methods */}
                    <div className="gonix-card-premium overflow-hidden">
                        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                            <Wallet className="h-4 w-4 text-sky-600" />
                            <h2 className="text-sm font-bold text-slate-800">แยกตามวิธีชำระ</h2>
                        </div>
                        <div className="p-5">
                            {summary.revenueByMethod.length === 0 ? (
                                <p className="text-center text-sm text-slate-400 py-8">ไม่มีข้อมูล</p>
                            ) : (
                                <div className="space-y-3">
                                    {summary.revenueByMethod.map(r => {
                                        const PIcon = PAYMENT_METHOD_ICON[r.method] || Wallet;
                                        const totalMethodRev = summary.revenueByMethod.reduce((s, m) => s + Math.abs(m.amount), 0);
                                        const pct = totalMethodRev > 0 ? Math.round((Math.abs(r.amount) / totalMethodRev) * 100) : 0;
                                        return (
                                            <div key={r.method} className="flex items-center gap-3">
                                                <div className="h-9 w-9 rounded-xl bg-sky-50 flex items-center justify-center shrink-0">
                                                    <PIcon className="h-4 w-4 text-sky-600" />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex justify-between text-sm mb-0.5">
                                                        <span className="font-medium text-slate-700">{PAYMENT_METHOD_LABEL[r.method] || r.method}</span>
                                                        <span className="font-bold text-slate-800 tabular-nums">฿{fmt(r.amount)}</span>
                                                    </div>
                                                    <div className="flex items-center gap-2">
                                                        <div className="flex-1 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                                                            <div className="h-full bg-sky-400 rounded-full" style={{ width: `${pct}%` }} />
                                                        </div>
                                                        <span className="text-[10px] text-slate-400 w-16 text-right">{r.count} ครั้ง</span>
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Visits by category */}
                    <div className="gonix-card-premium overflow-hidden lg:col-span-2">
                        <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                            <Activity className="h-4 w-4 text-violet-600" />
                            <h2 className="text-sm font-bold text-slate-800">Visit แยกตามประเภทบริการ</h2>
                        </div>
                        <div className="p-5">
                            {summary.revenueByCategory.length === 0 ? (
                                <p className="text-center text-sm text-slate-400 py-8">ไม่มี Visit ในช่วงนี้</p>
                            ) : (
                                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
                                    {summary.revenueByCategory.map(c => (
                                        <div key={c.category} className="rounded-xl border border-slate-200 p-3 text-center">
                                            <div className="text-2xl font-black text-slate-800 tabular-nums">{c.count}</div>
                                            <div className="text-[11px] text-slate-500 mt-0.5">{CATEGORY_LABEL[c.category] || c.category}</div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* ── SALES ── */}
            {tab === "sales" && (
                <div className="gonix-card-premium overflow-hidden">
                    <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                        <FileText className="h-4 w-4 text-teal-600" />
                        <h2 className="text-sm font-bold text-slate-800">ยอดขายแยกตามประเภทรายการ</h2>
                    </div>
                    <div className="p-5">
                        {summary.salesByType.length === 0 ? (
                            <p className="text-center text-sm text-slate-400 py-8">ไม่มียอดขายในช่วงนี้</p>
                        ) : (
                            <div className="space-y-3">
                                {(() => {
                                    const totalSales = summary.salesByType.reduce((s, t) => s + t.amount, 0);
                                    return summary.salesByType.map(t => {
                                        const pct = totalSales > 0 ? Math.round((t.amount / totalSales) * 100) : 0;
                                        return (
                                            <div key={t.type}>
                                                <div className="flex items-center justify-between mb-1">
                                                    <span className={`text-[11px] font-bold px-2 py-0.5 rounded uppercase ${ITEM_TYPE_COLOR[t.type] || ITEM_TYPE_COLOR.other}`}>
                                                        {ITEM_TYPE_LABEL[t.type] || t.type}
                                                    </span>
                                                    <div className="text-sm">
                                                        <span className="font-bold text-slate-800 tabular-nums">฿{fmt2(t.amount)}</span>
                                                        <span className="text-slate-400 ml-2 text-xs">{pct}% · {t.count} รายการ</span>
                                                    </div>
                                                </div>
                                                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                                                    <div className="h-full bg-gradient-to-r from-teal-400 to-sky-500 rounded-full" style={{ width: `${pct}%` }} />
                                                </div>
                                            </div>
                                        );
                                    });
                                })()}
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* ── TOP ITEMS ── */}
            {tab === "items" && (
                <div className="gonix-card-premium overflow-hidden">
                    <div className="px-5 py-3 border-b border-slate-100 flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-rose-600" />
                        <h2 className="text-sm font-bold text-slate-800">รายการขายดี (Top 15)</h2>
                    </div>
                    {summary.topItems.length === 0 ? (
                        <p className="text-center text-sm text-slate-400 py-12">ไม่มีรายการขายในช่วงนี้</p>
                    ) : (
                        <table className="w-full text-sm">
                            <thead className="bg-slate-50/60">
                                <tr className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                    <th className="text-left px-5 py-2.5 w-10">#</th>
                                    <th className="text-left px-4 py-2.5">รายการ</th>
                                    <th className="text-left px-4 py-2.5">ประเภท</th>
                                    <th className="text-center px-4 py-2.5">จำนวน</th>
                                    <th className="text-right px-5 py-2.5">ยอดขาย</th>
                                </tr>
                            </thead>
                            <tbody>
                                {summary.topItems.map((it, i) => (
                                    <tr key={i} className="border-t border-slate-100 hover:bg-slate-50/40">
                                        <td className="px-5 py-2.5 text-slate-400 font-bold tabular-nums">{i + 1}</td>
                                        <td className="px-4 py-2.5 font-bold text-slate-800">{it.name}</td>
                                        <td className="px-4 py-2.5">
                                            <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${ITEM_TYPE_COLOR[it.type] || ITEM_TYPE_COLOR.other}`}>
                                                {ITEM_TYPE_LABEL[it.type] || it.type}
                                            </span>
                                        </td>
                                        <td className="px-4 py-2.5 text-center tabular-nums text-slate-600">{fmt(it.qty)}</td>
                                        <td className="px-5 py-2.5 text-right font-bold text-emerald-700 tabular-nums">฿{fmt2(it.amount)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    )}
                </div>
            )}

            {/* Outstanding modal */}
            {showOutstanding && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4" onClick={() => setShowOutstanding(false)}>
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-between p-5 border-b border-slate-100">
                            <div>
                                <h2 className="font-bold text-lg text-slate-800 flex items-center gap-2">
                                    <AlertTriangle className="h-5 w-5 text-amber-600" /> ใบเสร็จค้างชำระ
                                </h2>
                                <p className="text-xs text-slate-500 mt-0.5">{outstanding.length} ใบ · รวม ฿{fmt2(outstanding.reduce((s, o) => s + o.balance, 0))}</p>
                            </div>
                            <button onClick={() => setShowOutstanding(false)} className="h-8 w-8 rounded-lg hover:bg-slate-100 flex items-center justify-center">
                                <X className="h-4 w-4 text-slate-500" />
                            </button>
                        </div>
                        <div className="flex-1 overflow-y-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-slate-50/60 sticky top-0">
                                    <tr className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                        <th className="text-left px-4 py-2">ใบเสร็จ</th>
                                        <th className="text-left px-4 py-2">คนไข้</th>
                                        <th className="text-right px-4 py-2">ค้าง</th>
                                        <th className="w-8"></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {outstanding.map(o => (
                                        <tr key={o.id} className="border-t border-slate-100 hover:bg-slate-50/40">
                                            <td className="px-4 py-2.5">
                                                <Link href={`/dashboard/finance/${o.id}`} className="font-mono text-[11px] text-sky-600 hover:underline">
                                                    {o.id}
                                                </Link>
                                                <div className="text-[10px] text-slate-400">{formatDateThai(o.invoice_date)}</div>
                                            </td>
                                            <td className="px-4 py-2.5">
                                                <div className="font-medium text-slate-700">{o.patient_name}</div>
                                                <div className="text-[10px] text-slate-400 font-mono">{o.hn}</div>
                                            </td>
                                            <td className="px-4 py-2.5 text-right">
                                                <div className="font-bold text-amber-700 tabular-nums">฿{fmt2(o.balance)}</div>
                                                <div className="text-[10px] text-slate-400">{STATUS_LABEL[o.status] || o.status}</div>
                                            </td>
                                            <td className="px-2">
                                                <Link href={`/dashboard/finance/${o.id}`}>
                                                    <ChevronRight className="h-4 w-4 text-slate-400" />
                                                </Link>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

function PresetBtn({ onClick, children }: { onClick: () => void; children: React.ReactNode }) {
    return (
        <button onClick={onClick} className="h-8 px-3 rounded-lg text-xs font-bold text-slate-600 hover:bg-white hover:text-teal-700 transition-all">
            {children}
        </button>
    );
}

function TabBtn({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
    return (
        <button
            onClick={onClick}
            className={`h-9 px-4 rounded-lg text-sm font-bold transition-all ${active ? "bg-white text-teal-700 shadow-sm" : "text-slate-600 hover:text-slate-800"}`}
        >
            {children}
        </button>
    );
}

function StatCard({ icon: Icon, label, value, color, sub }: {
    icon: React.ElementType;
    label: string;
    value: string;
    color: "emerald" | "amber" | "sky" | "violet";
    sub?: string;
}) {
    const styles = {
        emerald: { bg: "bg-emerald-50/60", iconBg: "bg-emerald-100", iconText: "text-emerald-700", valueText: "text-emerald-800" },
        amber: { bg: "bg-amber-50/60", iconBg: "bg-amber-100", iconText: "text-amber-700", valueText: "text-amber-800" },
        sky: { bg: "bg-sky-50/60", iconBg: "bg-sky-100", iconText: "text-sky-700", valueText: "text-sky-800" },
        violet: { bg: "bg-violet-50/60", iconBg: "bg-violet-100", iconText: "text-violet-700", valueText: "text-violet-800" },
    }[color];
    return (
        <div className={`rounded-2xl border border-slate-200/60 ${styles.bg} p-4`}>
            <div className={`h-10 w-10 rounded-xl ${styles.iconBg} flex items-center justify-center mb-3`}>
                <Icon className={`h-5 w-5 ${styles.iconText}`} />
            </div>
            <div className={`text-2xl font-black ${styles.valueText} tabular-nums`}>{value}</div>
            <div className="text-sm font-medium text-slate-700 mt-0.5">{label}</div>
            {sub && <div className="text-[11px] text-slate-400 mt-0.5">{sub}</div>}
        </div>
    );
}
