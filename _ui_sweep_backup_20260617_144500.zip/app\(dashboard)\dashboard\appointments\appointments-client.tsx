"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
    Clock, ChevronLeft, ChevronRight, Plus, CheckCircle, XCircle, RefreshCw,
    Calendar as CalIcon, CalendarDays, LayoutGrid,
} from "lucide-react";
import { cn } from "@/lib/utils";
import NewAppointmentModal from "./new-appointment-modal";
import { updateAppointmentStatus } from "@/lib/actions/appointments";
import { PermissionButton } from "@/components/ui/permission-button";

type ViewMode = "week" | "month" | "day";

const statusColors: Record<string, string> = {
    confirmed: "bg-emerald-100 text-emerald-700",
    pending: "bg-amber-100 text-amber-700",
    cancelled: "bg-red-100 text-red-600 line-through opacity-60",
    completed: "bg-slate-100 text-slate-500",
    no_show: "bg-red-50 text-red-400",
};

const statusLabels: Record<string, string> = {
    confirmed: "ยืนยัน",
    pending: "รอยืนยัน",
    cancelled: "ยกเลิก",
    completed: "เสร็จสิ้น",
    no_show: "ไม่มา",
};

// Doctor color palette
const DOCTOR_COLORS = [
    { bg: "bg-violet-100", text: "text-violet-700", border: "border-violet-300", dot: "bg-violet-500" },
    { bg: "bg-sky-100", text: "text-sky-700", border: "border-sky-300", dot: "bg-sky-500" },
    { bg: "bg-rose-100", text: "text-rose-700", border: "border-rose-300", dot: "bg-rose-500" },
    { bg: "bg-amber-100", text: "text-amber-700", border: "border-amber-300", dot: "bg-amber-500" },
    { bg: "bg-emerald-100", text: "text-emerald-700", border: "border-emerald-300", dot: "bg-emerald-500" },
    { bg: "bg-cyan-100", text: "text-cyan-700", border: "border-cyan-300", dot: "bg-cyan-500" },
];

const THAI_DAYS_SHORT = ["จ.", "อ.", "พ.", "พฤ.", "ศ.", "ส.", "อา."];
const THAI_MONTHS = ["มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"];

interface Doctor {
    id: string;
    profiles: { full_name: string } | { full_name: string }[];
}

interface Appointment {
    id: string;
    appt_date: string;
    appt_start: string | null;
    appt_end?: string | null;
    appt_type?: string | null;
    status: string;
    note?: string | null;
    doctor_id?: string | null;
    hn?: string | null;
    patients?: { first_name: string; last_name: string; phone?: string } | { first_name: string; last_name: string; phone?: string }[];
    doctor?: { id: string; profiles?: { full_name: string } | { full_name: string }[] } | null;
}

export default function AppointmentsClient({
    appointments,
    view,
    baseDateISO,
    startISO,
    endISO,
    today,
    doctors,
}: {
    appointments: Appointment[];
    view: ViewMode;
    baseDateISO: string;
    startISO: string;
    endISO: string;
    today: string;
    doctors: Doctor[];
}) {
    const router = useRouter();
    const [showModal, setShowModal] = useState(false);
    const [updatingId, setUpdatingId] = useState<string | null>(null);
    const [localAppts, setLocalAppts] = useState(appointments);
    const [doctorFilter, setDoctorFilter] = useState<string>("all");

    const baseDate = new Date(baseDateISO + "T00:00:00");

    // Doctor color map
    const doctorColorMap = useMemo(() => {
        const map: Record<string, typeof DOCTOR_COLORS[0]> = {};
        doctors.forEach((d, i) => {
            map[d.id] = DOCTOR_COLORS[i % DOCTOR_COLORS.length];
        });
        return map;
    }, [doctors]);

    const filteredAppts = useMemo(() => {
        if (doctorFilter === "all") return localAppts;
        return localAppts.filter(a => a.doctor_id === doctorFilter);
    }, [localAppts, doctorFilter]);

    // Group by date
    const byDate = useMemo(() => {
        const map: Record<string, Appointment[]> = {};
        filteredAppts.forEach(a => {
            if (!map[a.appt_date]) map[a.appt_date] = [];
            map[a.appt_date].push(a);
        });
        return map;
    }, [filteredAppts]);

    const totalAppts = filteredAppts.filter(a => a.status !== "cancelled").length;

    async function handleStatusChange(id: string, newStatus: string) {
        setUpdatingId(id);
        try {
            await updateAppointmentStatus(id, newStatus);
            setLocalAppts(prev => prev.map(a => a.id === id ? { ...a, status: newStatus } : a));
        } catch {
            // silent
        } finally {
            setUpdatingId(null);
        }
    }

    function shiftDate(direction: -1 | 1): string {
        const d = new Date(baseDate);
        if (view === "week") d.setDate(d.getDate() + direction * 7);
        else if (view === "month") d.setMonth(d.getMonth() + direction);
        else if (view === "day") d.setDate(d.getDate() + direction);
        return d.toISOString().split("T")[0];
    }

    const headerLabel = useMemo(() => {
        if (view === "month") {
            return `${THAI_MONTHS[baseDate.getMonth()]} ${baseDate.getFullYear() + 543}`;
        }
        if (view === "day") {
            return baseDate.toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
        }
        const startDate = new Date(startISO + "T00:00:00");
        const endDate = new Date(endISO + "T00:00:00");
        return `${startDate.toLocaleDateString("th-TH", { day: "numeric", month: "short" })} — ${endDate.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" })}`;
    }, [view, baseDate, startISO, endISO]);

    return (
        <div className="space-y-4 animate-fade-in relative z-10 font-sans pb-10">
            {/* Sub-header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-1">
                <div className="flex items-center gap-3 flex-wrap">
                    <p className="text-sm font-medium text-slate-500">
                        <span className="font-bold text-teal-700">{headerLabel}</span>
                        <span className="text-slate-300 mx-2">·</span>
                        <span><span className="font-bold text-slate-700 tabular-nums">{totalAppts}</span> นัด</span>
                    </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                    {/* View Toggle */}
                    <div className="inline-flex items-center bg-slate-100 rounded-xl p-1 gap-0.5">
                        <ViewToggleBtn active={view === "day"} href={`/dashboard/appointments?view=day&date=${baseDateISO}`} icon={CalIcon}>วัน</ViewToggleBtn>
                        <ViewToggleBtn active={view === "week"} href={`/dashboard/appointments?view=week&date=${baseDateISO}`} icon={LayoutGrid}>สัปดาห์</ViewToggleBtn>
                        <ViewToggleBtn active={view === "month"} href={`/dashboard/appointments?view=month&date=${baseDateISO}`} icon={CalendarDays}>เดือน</ViewToggleBtn>
                    </div>

                    {/* Doctor filter */}
                    {doctors.length > 1 && (
                        <select
                            value={doctorFilter}
                            onChange={e => setDoctorFilter(e.target.value)}
                            className="h-10 rounded-xl border border-slate-200 bg-white px-3 text-sm font-bold focus:outline-none focus:ring-2 focus:ring-teal-500/20"
                        >
                            <option value="all">หมอทั้งหมด ({doctors.length})</option>
                            {doctors.map(d => {
                                const name = Array.isArray(d.profiles) ? d.profiles[0]?.full_name : d.profiles?.full_name;
                                return <option key={d.id} value={d.id}>{name}</option>;
                            })}
                        </select>
                    )}

                    {/* Date nav */}
                    <div className="flex items-center gap-0.5 bg-white border border-slate-200 rounded-xl p-0.5 shadow-sm">
                        <Link href={`/dashboard/appointments?view=${view}&date=${shiftDate(-1)}`}>
                            <Button variant="ghost" size="sm" className="rounded-lg h-9 w-9 p-0">
                                <ChevronLeft className="h-4 w-4" />
                            </Button>
                        </Link>
                        <Link href={`/dashboard/appointments?view=${view}&date=${today}`}>
                            <Button variant="ghost" size="sm" className="rounded-lg font-bold h-9 px-3 text-xs">
                                วันนี้
                            </Button>
                        </Link>
                        <Link href={`/dashboard/appointments?view=${view}&date=${shiftDate(1)}`}>
                            <Button variant="ghost" size="sm" className="rounded-lg h-9 w-9 p-0">
                                <ChevronRight className="h-4 w-4" />
                            </Button>
                        </Link>
                    </div>

                    {/* Add New */}
                    <PermissionButton
                        permKey="appointments.create"
                        onClick={() => setShowModal(true)}
                        className="gap-1.5 rounded-xl bg-sky-600 hover:bg-sky-700 shadow-md shadow-sky-500/20 font-bold h-10"
                    >
                        <Plus className="h-4 w-4" /> นัดใหม่
                    </PermissionButton>
                </div>
            </div>

            {/* Views */}
            {view === "month" && <MonthView baseDate={baseDate} byDate={byDate} today={today} doctorColorMap={doctorColorMap} />}
            {view === "week" && (
                <WeekView
                    baseDate={baseDate}
                    byDate={byDate}
                    today={today}
                    doctorColorMap={doctorColorMap}
                    updatingId={updatingId}
                    onStatusChange={handleStatusChange}
                />
            )}
            {view === "day" && (
                <DayView
                    baseDate={baseDate}
                    appointments={filteredAppts.filter(a => a.appt_date === baseDateISO)}
                    doctorColorMap={doctorColorMap}
                    updatingId={updatingId}
                    onStatusChange={handleStatusChange}
                />
            )}

            {showModal && (
                <NewAppointmentModal
                    onClose={() => { setShowModal(false); router.refresh(); }}
                    doctors={doctors}
                />
            )}
        </div>
    );
}

function ViewToggleBtn({ active, href, icon: Icon, children }: {
    active: boolean;
    href: string;
    icon: React.ElementType;
    children: React.ReactNode;
}) {
    return (
        <Link href={href}>
            <button className={cn(
                "inline-flex items-center gap-1.5 h-9 px-3 rounded-lg text-xs font-bold transition-all",
                active ? "bg-white text-teal-700 shadow-sm" : "text-slate-600 hover:text-slate-800"
            )}>
                <Icon className="h-3.5 w-3.5" />
                {children}
            </button>
        </Link>
    );
}

// ─── MONTH VIEW ──────────────────────────────────────
function MonthView({
    baseDate, byDate, today, doctorColorMap,
}: {
    baseDate: Date;
    byDate: Record<string, Appointment[]>;
    today: string;
    doctorColorMap: Record<string, typeof DOCTOR_COLORS[0]>;
}) {
    const year = baseDate.getFullYear();
    const month = baseDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const firstDow = firstDay.getDay() === 0 ? 6 : firstDay.getDay() - 1; // Monday start

    const dates: Date[] = [];
    const gridStart = new Date(firstDay);
    gridStart.setDate(gridStart.getDate() - firstDow);
    for (let i = 0; i < 42; i++) {
        const d = new Date(gridStart);
        d.setDate(gridStart.getDate() + i);
        dates.push(d);
    }
    // Trim trailing empty rows
    const totalRows = Math.ceil(dates.length / 7);
    const trimmed = dates.slice(0, totalRows * 7);

    return (
        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            {/* Day headers */}
            <div className="grid grid-cols-7 border-b border-slate-200 bg-slate-50">
                {THAI_DAYS_SHORT.map(d => (
                    <div key={d} className="text-center py-2.5 text-xs font-bold text-slate-600 uppercase tracking-wider">{d}</div>
                ))}
            </div>

            {/* Date cells */}
            <div className="grid grid-cols-7 grid-rows-6">
                {trimmed.map((date, i) => {
                    const key = date.toISOString().split("T")[0];
                    const dayAppts = (byDate[key] || []).filter(a => a.status !== "cancelled");
                    const isToday = key === today;
                    const isCurrentMonth = date.getMonth() === month;
                    const isLastRow = i >= trimmed.length - 7;
                    return (
                        <Link
                            key={i}
                            href={`/dashboard/appointments?view=day&date=${key}`}
                            className={cn(
                                "min-h-[110px] border-r border-b border-slate-100 p-2 hover:bg-teal-50/40 transition-colors",
                                (i + 1) % 7 === 0 && "border-r-0",
                                isLastRow && "border-b-0",
                                !isCurrentMonth && "bg-slate-50/40"
                            )}
                        >
                            <div className="flex items-center justify-between mb-1">
                                <span className={cn(
                                    "inline-flex items-center justify-center text-xs font-bold rounded-full",
                                    isToday ? "h-6 w-6 bg-teal-600 text-white" : isCurrentMonth ? "text-slate-700" : "text-slate-400"
                                )}>
                                    {date.getDate()}
                                </span>
                                {dayAppts.length > 0 && (
                                    <span className="text-[10px] font-bold text-slate-500">{dayAppts.length}</span>
                                )}
                            </div>
                            <div className="space-y-0.5">
                                {dayAppts.slice(0, 3).map(a => {
                                    const pt = Array.isArray(a.patients) ? a.patients[0] : a.patients;
                                    const color = a.doctor_id ? doctorColorMap[a.doctor_id] : DOCTOR_COLORS[0];
                                    return (
                                        <div key={a.id} className={cn("text-[10px] truncate px-1 py-0.5 rounded font-medium", color?.bg, color?.text)}>
                                            <span className="font-mono">{a.appt_start?.slice(0, 5)}</span> {pt?.first_name}
                                        </div>
                                    );
                                })}
                                {dayAppts.length > 3 && (
                                    <div className="text-[9px] text-slate-500 px-1 font-medium">+{dayAppts.length - 3} เพิ่ม</div>
                                )}
                            </div>
                        </Link>
                    );
                })}
            </div>
        </div>
    );
}

// ─── WEEK VIEW ──────────────────────────────────────
function WeekView({
    baseDate, byDate, today, doctorColorMap, updatingId, onStatusChange,
}: {
    baseDate: Date;
    byDate: Record<string, Appointment[]>;
    today: string;
    doctorColorMap: Record<string, typeof DOCTOR_COLORS[0]>;
    updatingId: string | null;
    onStatusChange: (id: string, status: string) => void;
}) {
    const dow = baseDate.getDay();
    const monday = new Date(baseDate);
    monday.setDate(baseDate.getDate() - (dow === 0 ? 6 : dow - 1));
    monday.setHours(0, 0, 0, 0);
    const dates: Date[] = [];
    for (let i = 0; i < 7; i++) {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        dates.push(d);
    }

    return (
        <div className="bg-white border border-slate-200 rounded-2xl p-3 overflow-x-auto shadow-sm">
            <div className="grid grid-cols-7 gap-2 min-w-[900px]">
                {dates.map(date => {
                    const key = date.toISOString().split("T")[0];
                    const isToday = key === today;
                    const dayAppts = byDate[key] || [];
                    const activeAppts = dayAppts.filter(a => a.status !== "cancelled");
                    const dow = date.getDay();
                    const dayIdx = dow === 0 ? 6 : dow - 1;

                    return (
                        <div key={key} className={cn("flex flex-col gap-2 rounded-xl p-1.5", isToday && "bg-teal-50")}>
                            <Link
                                href={`/dashboard/appointments?view=day&date=${key}`}
                                className={cn(
                                    "rounded-xl px-2 py-2 text-center transition-all border",
                                    isToday ? "bg-gradient-to-b from-teal-500 to-sky-600 border-transparent text-white" : "bg-white border-slate-200 hover:border-teal-300"
                                )}
                            >
                                <p className={cn("text-[10px] font-bold uppercase tracking-widest", isToday ? "text-white/80" : "text-slate-400")}>
                                    {THAI_DAYS_SHORT[dayIdx]}
                                </p>
                                <p className={cn("text-xl font-black mt-0.5", isToday ? "text-white" : "text-slate-700")}>
                                    {date.getDate()}
                                </p>
                                {activeAppts.length > 0 && (
                                    <p className={cn("text-[10px] mt-1 font-bold", isToday ? "text-white/80" : "text-slate-500")}>
                                        {activeAppts.length} นัด
                                    </p>
                                )}
                            </Link>

                            <div className="space-y-1.5 flex-1">
                                {dayAppts.length === 0 ? (
                                    <div className="h-full min-h-[60px] flex items-center justify-center rounded-xl border border-dashed border-slate-200">
                                        <p className="text-[10px] font-bold text-slate-300 uppercase">ว่าง</p>
                                    </div>
                                ) : (
                                    dayAppts.map(appt => (
                                        <AppointmentCard
                                            key={appt.id}
                                            appt={appt}
                                            doctorColorMap={doctorColorMap}
                                            isUpdating={updatingId === appt.id}
                                            onStatusChange={onStatusChange}
                                            compact
                                        />
                                    ))
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

// ─── DAY VIEW ──────────────────────────────────────
function DayView({
    baseDate, appointments, doctorColorMap, updatingId, onStatusChange,
}: {
    baseDate: Date;
    appointments: Appointment[];
    doctorColorMap: Record<string, typeof DOCTOR_COLORS[0]>;
    updatingId: string | null;
    onStatusChange: (id: string, status: string) => void;
}) {
    // Hours 8AM-19PM
    const hours = Array.from({ length: 12 }, (_, i) => 8 + i);

    function timeToMinutes(t: string | null | undefined): number {
        if (!t) return 0;
        const [h, m] = t.split(":").map(Number);
        return h * 60 + (m || 0);
    }

    const grouped: Record<number, Appointment[]> = {};
    appointments.forEach(a => {
        const h = parseInt((a.appt_start || "08:00").slice(0, 2));
        if (!grouped[h]) grouped[h] = [];
        grouped[h].push(a);
    });

    return (
        <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-200 bg-slate-50/60 flex items-center justify-between">
                <div className="text-sm font-bold text-slate-700">
                    {baseDate.toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                </div>
                <div className="text-xs text-slate-500">{appointments.filter(a => a.status !== "cancelled").length} นัดในวันนี้</div>
            </div>
            <div className="divide-y divide-slate-100">
                {hours.map(h => {
                    const slotAppts = (grouped[h] || []).sort((a, b) =>
                        timeToMinutes(a.appt_start) - timeToMinutes(b.appt_start)
                    );
                    return (
                        <div key={h} className="grid grid-cols-[80px_1fr] min-h-[80px]">
                            <div className="bg-slate-50/30 border-r border-slate-100 p-3 text-right">
                                <div className="text-sm font-bold text-slate-700">{String(h).padStart(2, "0")}:00</div>
                            </div>
                            <div className="p-2">
                                {slotAppts.length === 0 ? (
                                    <div className="h-full flex items-center text-xs text-slate-300 italic px-2">—</div>
                                ) : (
                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                        {slotAppts.map(appt => (
                                            <AppointmentCard
                                                key={appt.id}
                                                appt={appt}
                                                doctorColorMap={doctorColorMap}
                                                isUpdating={updatingId === appt.id}
                                                onStatusChange={onStatusChange}
                                            />
                                        ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

// ─── APPOINTMENT CARD ──────────────────────────────────────
function AppointmentCard({
    appt, doctorColorMap, isUpdating, onStatusChange, compact,
}: {
    appt: Appointment;
    doctorColorMap: Record<string, typeof DOCTOR_COLORS[0]>;
    isUpdating: boolean;
    onStatusChange: (id: string, status: string) => void;
    compact?: boolean;
}) {
    const pt = Array.isArray(appt.patients) ? appt.patients[0] : appt.patients;
    const color = appt.doctor_id ? doctorColorMap[appt.doctor_id] : DOCTOR_COLORS[0];
    const doctorProfile = Array.isArray(appt.doctor?.profiles) ? appt.doctor?.profiles[0] : appt.doctor?.profiles;
    const doctorName = doctorProfile?.full_name;

    return (
        <Card className={cn("rounded-xl shadow-sm transition-all bg-white border-l-4", color?.border, appt.status !== "cancelled" && "hover:shadow-md")}>
            <CardContent className={cn("p-2.5", !compact && "p-3")}>
                <div className="flex items-center gap-1.5 mb-1">
                    <Clock className={cn("h-3 w-3", color?.text)} />
                    <span className="text-[11px] font-bold font-mono text-slate-600">
                        {appt.appt_start?.slice(0, 5)}
                    </span>
                </div>
                <p className={cn(
                    "text-xs font-bold text-slate-800 line-clamp-1",
                    appt.status === "cancelled" && "line-through text-slate-400"
                )}>
                    {pt?.first_name} {compact ? pt?.last_name?.charAt(0) + "." : pt?.last_name}
                </p>
                {!compact && doctorName && (
                    <p className={cn("text-[10px] mt-0.5 font-medium", color?.text)}>👨‍⚕️ {doctorName}</p>
                )}
                {appt.note && (
                    <p className="text-[10px] text-slate-400 line-clamp-1 mt-1">{appt.note}</p>
                )}
                <div className="mt-1.5 flex items-center justify-between gap-1">
                    <Badge variant="outline" className={cn("text-[9px] px-1.5 py-0 border-transparent font-bold", statusColors[appt.status])}>
                        {statusLabels[appt.status] || appt.status}
                    </Badge>
                    <div className="flex gap-1">
                        {appt.status === "confirmed" && (
                            <>
                                <button
                                    disabled={isUpdating}
                                    onClick={() => onStatusChange(appt.id, "completed")}
                                    title="มาตามนัด"
                                    className="h-6 w-6 rounded-lg bg-emerald-50 hover:bg-emerald-100 flex items-center justify-center text-emerald-600 transition-colors"
                                >
                                    {isUpdating ? <RefreshCw className="h-3 w-3 animate-spin" /> : <CheckCircle className="h-3 w-3" />}
                                </button>
                                <button
                                    disabled={isUpdating}
                                    onClick={() => onStatusChange(appt.id, "cancelled")}
                                    title="ยกเลิก"
                                    className="h-6 w-6 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-500 transition-colors"
                                >
                                    <XCircle className="h-3 w-3" />
                                </button>
                            </>
                        )}
                        {appt.status === "pending" && (
                            <button
                                disabled={isUpdating}
                                onClick={() => onStatusChange(appt.id, "confirmed")}
                                className="h-6 w-6 rounded-lg bg-violet-50 hover:bg-violet-100 flex items-center justify-center text-violet-600 transition-colors"
                                title="ยืนยันนัด"
                            >
                                <CheckCircle className="h-3 w-3" />
                            </button>
                        )}
                    </div>
                </div>
            </CardContent>
        </Card>
    );
}
